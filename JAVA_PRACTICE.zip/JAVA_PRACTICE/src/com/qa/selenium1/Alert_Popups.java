package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_Popups {

	public static void main(String[] args) throws InterruptedException {


		System.setProperty("WebDriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		Thread.sleep(2000);
		
		
		driver.findElement(By.cssSelector("#name")).sendKeys("Pooja");
		driver.findElement(By.cssSelector("#alertbtn")).click();
		driver.switchTo().alert().accept();// Handles all positive popups
		
		driver.findElement(By.cssSelector("#confirmbtn")).click();
		Thread.sleep(1000);
		driver.switchTo().alert().dismiss();//Handles the all negative popups
		
		driver.close();
		
	}

}
