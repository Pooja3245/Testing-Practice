package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Assignment2
{
	public static void main(String args[]) throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//input[@name='name'])[1]")).sendKeys("Pooja");
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("Pooja@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"exampleInputPassword1\"]")).sendKeys("Pooja@gmail.com");
		driver.findElement(By.cssSelector("#exampleCheck1")).click();	
		driver.findElement(By.xpath("//*[@id=\"exampleFormControlSelect1\"]/option[2]")).click();
		driver.findElement(By.cssSelector("#inlineRadio1")).click();
		driver.findElement(By.cssSelector("input[value='Submit']")).click();
		
		Assert.assertEquals(driver.findElement(By.xpath("//div[@class='alert alert-success alert-dismissible']")).getText()," The Form has been submitted successfully!.");
		//div[@class='alert alert-success alert-dismissible']
		driver.close();
	}
}
