package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DropDown_Dynamic
{
	
	public static void main(String arg[]) throws InterruptedException
	{

		System.setProperty("WebDriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/dropdownsPractise");
		Thread.sleep(2000);
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		/*
		 * code by using the index or simply xpath
		 * 
		driver.findElement(By.xpath("(//a[@value='DEL'])")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//a[@value='SXR'])[2]")).click();
		*/
		
		
		// code using the parent to child path
		driver.findElement(By.xpath("//table[@id='citydropdown'] //a[@value=\"DEL\"]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value=\"SXR\"]")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[2]/td[5]")).click();
		Thread.sleep(1000);
		
		driver.close();
	
	}

}
