package com.qa.selenium1;

import java.util.stream.Stream;

import org.testng.annotations.Test;

@Test
public class Stream_practice {

	public void method() {
	long counte= Stream.of("Pooja","Akshay","Priti","Ankit").filter(P->P.startsWith("A")).count();
	System.out.println(counte);

	Stream.of("Pooja","Akshay","Priti","Ankit").filter(P->
	{
		P.startsWith("A");
		return true;//if return false then terminal operation will not execute
	}).count();//terminal operation
	
		
	}
}
