package com.qa.selenium1;

import java.util.ArrayList;

import org.testng.annotations.Test;

public class Stream_vs_arraylist{

	@Test
	public void Method() {

		int count = 0;
		ArrayList<String> array = new ArrayList<String>();
		array.add("Pooja");
		array.add("Pratiksha");
		array.add("bushra");
		array.add("ayesha");
		array.add("dnyanu");

		//Create arraylist then converted into the stream then count the number
		
//		long count1 = array.stream().filter(p->p.startsWith("a")).count();
//		System.out.println(count1);

		//without using the stram there alots of number of lines code
		for (int i = 0; i < array.size(); i++) {
			if (array.get(i).startsWith("a")) {
				count++;
			}
		}
		System.out.println(count);

		
	
	}

}
