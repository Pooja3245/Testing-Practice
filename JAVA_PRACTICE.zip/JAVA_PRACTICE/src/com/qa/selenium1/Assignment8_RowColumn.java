package com.qa.selenium1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment8_RowColumn {

	public static void main(String arg[]) throws InterruptedException {
		System.setProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(1000);
		js.executeScript("document.querySelector('.table-display').scrollTop=500;");
		Thread.sleep(1000);

		int count = driver.findElements(By.xpath("//*[@class='table-display']/tbody/tr")).size();
		int row = 1;
		for(int i=0;i<count;i++)
		{
			row = row + 1;
		}
		System.out.println(row);
		
		int count1 = driver.findElements(By.xpath("//*[@id=\"product\"]/tbody/tr[1]/th")).size();
		int column = 1;
		for(int i=0;i<count1;i++)
		{
			column = column+1;
		}
		System.out.println(column);
		
		List<WebElement> count2 = driver.findElements(By.xpath("//*[@class=\"table-display\"]/tbody/tr/td[3]"));
		int prize = 0;
		for(int i=0;i<count2.size();i++)
		{
			prize = prize + Integer.parseInt(count2.get(i).getText());
		}
		System.out.println(prize);
		driver.close();
	}
}
