package com.qa.selenium1;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.annotations.Test;

@Test
public class Stream_to_list {

	//
	public void fun() {
		List<String> obj = Stream.of("Pooja", "Akshay", "Atharva", "Aankit").sorted().map(s -> s.toUpperCase())
				.collect(Collectors.toList());
		System.out.println(obj.get(0));
	}

}
