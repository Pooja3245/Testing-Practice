package com.qa.selenium1;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment6_footerscreenchange {

	public static void main(String args[]) {
		System.getProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("http://qaclickacademy.com/practice.php");

		System.out.println(driver.findElements(By.tagName("a")).size());

		WebElement driverfooter = driver.findElement(By.id("gf-BIG"));// limiting the driver to specific section
		System.out.println(driverfooter.findElements(By.tagName("a")).size());


		WebElement columnFooter = driverfooter.findElement(By.xpath("//*[@id=\"gf-BIG\"]/table/tbody/tr/td[1]/ul"));
		int n = columnFooter.findElements(By.xpath("//*[@id=\"gf-BIG\"]/table/tbody/tr/td[1]/ul/li")).size();

		for (int i = 1; i < n; i++) {

			System.out.println("Page name:" + columnFooter.findElements(By.xpath("//*[@id=\"gf-BIG\"]/table/tbody/tr/td[1]/ul/li")).get(i).getText());
			String ClickElement = Keys.chord(Keys.CONTROL, Keys.ENTER);
			columnFooter.findElements(By.tagName("a")).get(i).sendKeys(ClickElement);

			
		}
			
		Set<String> str = driver.getWindowHandles();
		Iterator<String> itr = str.iterator();
		
		while(itr.hasNext())
			{
				//driver.switchTo().window(itr.next());
				driver.switchTo().window(itr.next());
				System.out.println(driver.getTitle());
		}

		driver.quit();

}
}