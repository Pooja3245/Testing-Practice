package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


//In dropdown add the number of passengers that you want
public class Dropdown_addnumber 
{
	
	public static void main(String arg[]) throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.chromedriver","D:\\selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.findElement(By.id("divpaxinfo")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.id("hrefIncAdt")).getText());

		for(int i=1;i<5;i++)
		{
			driver.findElement(By.id("hrefIncAdt")).click();
		}
		
		System.out.println(driver.findElement(By.id("hrefIncAdt")).getText());
		
		driver.close();
		
	}

}
