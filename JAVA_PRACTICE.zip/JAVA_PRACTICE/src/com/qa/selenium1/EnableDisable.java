package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class EnableDisable 
{
	
	public static void main(String arg[]) throws InterruptedException
	{
		

		System.setProperty("WebDriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/dropdownsPractise");
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("#ctl00_mainContent_rbtnl_Trip")).click();	
		//Assert.assertTrue(driver.findElement(By.cssSelector("#ctl00_mainContent_rbtnl_Trip")).isEnabled());
		//style="display: block; opacity: 1;"
		//driver.findElement(By.cssSelector("#ctl00_mainContent_rbtnl_Trip_0")).click();	
	
	
		if(driver.findElement(By.id("#Div1")).getAttribute("style").contains("1"))
		{
			Assert.assertTrue(true);
		}
		else
		{
			
		}Assert.assertFalse(false);
	
	}

}
