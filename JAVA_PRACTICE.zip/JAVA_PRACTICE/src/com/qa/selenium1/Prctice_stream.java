package com.qa.selenium1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.annotations.Test;

@Test
public class Prctice_stream {

	public void fun()
	{
		List<Integer> intObj = Arrays.asList(1,2,3,4,5,1,2,4);
		//intObj.stream().distinct().forEach(s->System.out.println(s));
		//intObj.stream().sorted().forEach(s->System.out.println(s));

		//unique sorted order and fetched 3rd index
		List<Integer> intObj1 =intObj.stream().distinct().sorted().collect(Collectors.toList());
		intObj1.get(3);
	}
}
