package com.qa.selenium1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Autosuggestion_Dropdown 
{
	
	public static void main(String args[]) throws InterruptedException
	{
		System.setProperty("WebDriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/dropdownsPractise");
		Thread.sleep(1000);
		
		driver.findElement(By.id("autosuggest")).sendKeys("ind");
		//List all the element conts the ind in it
		List<WebElement>Suggestion = driver.findElements(By.xpath("//*[@class=\"ui-menu-item\"] //a"));
		
		
		//click on the india dropdown
		for(WebElement ele : Suggestion)
		{
			if(ele.getText().equalsIgnoreCase("india"))
			{
				ele.click();
				break;
			}
		}
		
		driver.close();
		
	}

}
