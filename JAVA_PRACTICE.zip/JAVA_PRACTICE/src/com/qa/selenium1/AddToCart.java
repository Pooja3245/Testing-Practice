package com.qa.selenium1;

import java.util.Arrays;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddToCart {
	
	@SuppressWarnings("deprecation")
	public static void main(String arg[]) throws InterruptedException {

		String[] array = { "Tomato", "Brocolli", "Mango" };
		List<String> al = Arrays.asList(array);

		System.setProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);

		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		Thread.sleep(3000);

		List<WebElement> obj = driver.findElements(By.cssSelector(".product-name"));
		for (int i = 0; i < obj.size(); i++) {
			String[] name = obj.get(i).getText().split("-");;

			String formattedName=name[0].trim();

			
			if (al.contains(formattedName)) {
				Thread.sleep(2000);
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
				
				int flag=1;
				
				if(flag==array.length)
				{
					break;
				}		
			}
		}
		driver.close();
	}

}

