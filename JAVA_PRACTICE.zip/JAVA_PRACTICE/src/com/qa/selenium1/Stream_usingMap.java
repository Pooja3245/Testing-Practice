package com.qa.selenium1;

import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

@Test
public class Stream_usingMap {

	public void fun() {
//		Stream.of("Pooja", "Akshay", "Atharva", "Aankit").filter(s -> s.endsWith("a")).map(s -> s.toUpperCase())
//				.forEach(s -> System.out.println(s));
//		
		// to uppar case only
//		Stream.of("Pooja", "Akshay", "Atharva", "Aankit").map(s -> s.toUpperCase())
//		.forEach(s -> System.out.println(s));
//		
//			sorting the array
//		
//		Stream.of("Pooja", "Akshay", "Atharva", "Aankit").sorted().map(s -> s.toUpperCase())
//		.forEach(s -> System.out.println(s));
//		
//		Concating two string

		Stream<String> str = Stream.of("Pooja", "Akshay", "Atharva", "Aankit");
		Stream<String> str1 = Stream.of("Akhilesh", "Kunal", "Soumyajit", "Roshni");
		Stream<String> finalStr = Stream.concat(str, str1);
//		finalStr.sorted().forEach(s -> System.out.println(s));
		boolean matcStr =finalStr.anyMatch(s -> s.equalsIgnoreCase("Pooja"));
		System.out.println(matcStr);
		Assert.assertTrue(matcStr);

	}

}
