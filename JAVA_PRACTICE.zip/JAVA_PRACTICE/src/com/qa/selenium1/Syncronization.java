package com.qa.selenium1;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Syncronization {

	@SuppressWarnings("deprecation")
	public static void main(String Arg[]) throws InterruptedException {

		System.getProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		String array[] = { "Tomato", "Brocolli", "Mango" };
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");

		List<WebElement> productname = driver.findElements(By.cssSelector(".product-name"));

		for (int i = 0; i < productname.size(); i++) {

			List<String> al = Arrays.asList(array);
			Thread.sleep(1000);
			String  name [] = productname.get(i).getText().split("-");
			
			//String [] name = productname.get(i).getText().split("-");
			String formattedName = name[0].trim();
			Thread.sleep(1000);

			// System.out.println(driver.findElements(By.cssSelector(".product-name")).get(i).getText());
			Thread.sleep(1000);
			if (al.contains(formattedName)) {

				driver.findElements(By.xpath("//div[@class=\"product-action\"]/button")).get(i).click();

				int flag = 1;

				if (flag == al.size()) {
					break;
				}

			}

			driver.close();
		}

	}

}
