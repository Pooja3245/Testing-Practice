package com.qa.selenium1;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Assertion_splitstring{

	public static void main(String[] args) throws InterruptedException
	{
		String name="Pooja";
	
	
		System.getProperty("Webdriver.chrome.chromedriver","D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		String password = getPassword(driver);
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.id("inputUsername")).sendKeys(name);	
		driver.findElement(By.name("inputPassword")).sendKeys(password);
		driver.findElement(By.className("signInBtn")).click();
		Thread.sleep(1000);
		
		//Assertion Code
		
		System.out.println(driver.findElement(By.tagName("p")).getText());
		Assert.assertEquals(driver.findElement(By.tagName("p")).getText(),"You are successfully logged in.");
		
		System.out.println(driver.findElement(By.cssSelector("div[class='login-container'] h2")).getText());
		Assert.assertEquals(driver.findElement(By.cssSelector("div[class='login-container'] h2")).getText(),"Hello "+name+",");
		Thread.sleep(1000);
		
		driver.close();
		
		
	}

	//code for get the password from the string
	public static String getPassword(WebDriver driver) throws InterruptedException
	{
		driver.get("https://rahulshettyacademy.com/locatorspractice/");

		driver.findElement(By.linkText("Forgot your password?")).click();
		driver.findElement(By.xpath("//*[@id=\"container\"]/div[1]/form/div/button[2]")).click();
		Thread.sleep(1000);
		//System.out.println(driver.findElement(By.cssSelector("form p")).getText());
		String passwordstr = driver.findElement(By.cssSelector("form p")).getText();		
		String passwordArray1[]= passwordstr.split("'");
		String passwordArray2[]=passwordArray1[1].split("'");		
		String password = passwordArray2[0];

		return password;
	}
	
	
}
