package com.qa.selenium1;

import java.time.Duration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment3 {

	public static void main(String arg[]) {

		System.getProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		String str = driver.findElement(By.xpath("//*[@id=\"login-form\"]/div[7]")).getText();

		String Username = str.split("and")[0].trim().split("is")[1].trim();
		//System.out.println(Username);

		driver.findElement(By.cssSelector("#username")).sendKeys(Username);
		driver.findElement(By.cssSelector("#password")).sendKeys("learning");

		driver.findElement(By.xpath("(//span[@class='checkmark'])[2]")).click();
		WebDriverWait waitobj = new WebDriverWait(driver, Duration.ofMillis(7000));

		waitobj.until(ExpectedConditions.visibilityOfElementLocated(By.id("okayBtn")));
		driver.findElement(By.id("okayBtn")).click();

		WebElement obj = driver.findElement(By.xpath("//select[@class='form-control']"));//*[ ->error
		Select sc = new Select(obj);
		sc.selectByValue("consult");
		driver.findElement(By.cssSelector("#terms"));
		driver.findElement(By.id("signInBtn")).click();
		
	List<WebElement> itr = driver.findElements(By.xpath("//div[@class=\"card h-100\"] "));
	
	for(int i=0;i<itr.size();i++)
	{
		driver.findElement(By.xpath("//button[@class=\"btn btn-info\"]")).click();
		//System.out.println(driver.findElement(By.xpath("//button[@class=\"btn btn-info\"]")));
	}

	driver.findElement(By.xpath("//a[@class='nav-link btn btn-primary']")).click();
	//System.out.println(driver.findElement(By.xpath("//a[@class='nav-link btn btn-primary']")).getText());
	driver.close();
	}
	
	
	
}

