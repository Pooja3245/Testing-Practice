package com.qa.selenium1;

import java.time.Duration;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;


public class Locators_Syntax {

	public static void main(String[] args) throws InterruptedException {

		//implicit wait - 2 seconds time out

		System.setProperty("WebDriver.chrome.chromedriver","D:\\selenium\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.get("https://rahulshettyacademy.com/locatorspractice/");

		driver.findElement(By.id("inputUsername")).sendKeys("pooja");

		driver.findElement(By.name("inputPassword")).sendKeys("pooja123");

		driver.findElement(By.className("signInBtn")).click();

		System.out.println(driver.findElement(By.cssSelector("p.error")).getText());//tagname.class	

		driver.findElement(By.linkText("Forgot your password?")).click();

		Thread.sleep(1000);//

		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Pooja");

		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("Pooja@.com");

		driver.findElement(By.xpath("//input[@type='text'][2]")).clear();

		driver.findElement(By.cssSelector("input[type='text']:nth-child(3)")).sendKeys("pooja@gmail.com");

		driver.findElement(By.xpath("//form/input[3]")).sendKeys("9864353253");
		//driver.findElement(By.cssSelector("input[type='text']:nth-child(4)']")).sendKeys("123456");


		driver.findElement(By.cssSelector(".reset-pwd-btn")).click();
		Thread.sleep(4000);
		System.out.println(driver.findElement(By.cssSelector("form p")).getText());

		driver.findElement(By.xpath("//div[@class='forgot-pwd-btn-conainer']/button[1]")).click();
		//*[@id="container"]/div[1]/form/div/button[1]
		Thread.sleep(1000);

		driver.findElement(By.cssSelector("#inputUsername")).sendKeys("pooja");

		driver.findElement(By.cssSelector("input[type*='pass']")).sendKeys("rahulshettyacademy");
		//* - contains the pass in password $ end with ^ starts with

		driver.findElement(By.id("chkboxOne")).click();

		driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click();//classname 2 so that contains

	}



}

