package com.qa.selenium1;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment7_Checkbox_Dropdown_alert {

	public static void main(String args[]) throws InterruptedException {
		System.getProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("http://qaclickacademy.com/practice.php");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//
//		WebElement ele = driver.findElement(By.id("checkbox-example"));
//		int Count = ele.findElements(By.xpath("//input[@type='checkbox']")).size();
//
//		for (int i = 0; i < Count; i++) {
//			if (i == 1) {
//				ele.findElement(By.xpath("//input[@type='checkbox']")).click();
//			}
//			
//		}
//
//		System.out.println(ele.findElement(By.xpath("//input[@type='checkbox']")).getText());

		driver.findElement(By.xpath("//div[1]/div[4]/fieldset/label[3]/input")).click();
	//	System.out.println(driver.findElement(By.xpath("//div[1]/div[4]/fieldset/label[3]")).getText());
		String str = driver.findElement(By.xpath("//div[1]/div[4]/fieldset/label[3]")).getText();
		driver.findElement(By.xpath("//*[@id=\"dropdown-class-example\"]")).sendKeys(str);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys(str);
		driver.findElement(By.xpath("//*[@id=\"alertbtn\"]")).click();
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}
}