package com.qa.selenium1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//back the page, next page
public class WindowActivities {

public static void main(String[] args) {

System.setProperty("webdriver.chrome.driver", "/Users/rahulshetty/Documents/chromedriver");
WebDriver driver = new ChromeDriver();

driver.manage().window().maximize();

driver.get("http://google.com");//wait until the page is load

driver.navigate().to("https://rahulshettyacademy.com");

driver.navigate().back();

driver.navigate().forward();

}



}

