package com.qa.selenium1;

import java.util.stream.Stream;

import org.testng.annotations.Test;

@Test
public class Stream_Practice1 {

	public void fun() {
		// write the letter greater than 4
		//Stream.of("Akshay","Pooja","Atharv","Aditya").filter(p->p.length()>4).forEach(s->System.out.println(s));

		// limit only one result
		Stream.of("Akshay", "Pooja", "Atharv", "Aditya").filter(p -> p.length() > 4).limit(1)
				.forEach(s -> System.out.println(s));
		
		
	}

}
