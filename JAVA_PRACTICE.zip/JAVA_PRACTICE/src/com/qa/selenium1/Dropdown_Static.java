package com.qa.selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

// In static dropdown- in dropdown already some fixed numers are present [only 3 citys given randomly ] 
public class Dropdown_Static
{
	public static void main(String arg[]) throws InterruptedException
	{
		
		System.setProperty("WebDriver.chrome.chromedriver","D:\\selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.manage().window().maximize();
		
		WebElement Webeleobj= driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		Select selectObj = new Select(Webeleobj);
		
		selectObj.selectByIndex(2);
		System.out.println(selectObj.getFirstSelectedOption().getText());
		selectObj.selectByValue("INR");
		System.out.println(selectObj.getFirstSelectedOption().getText());
		selectObj.selectByVisibleText("USD");
		Thread.sleep(1000);
		
		driver.close();
		
	}
	
}
