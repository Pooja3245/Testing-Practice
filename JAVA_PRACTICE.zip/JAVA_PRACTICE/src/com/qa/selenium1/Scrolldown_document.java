package com.qa.selenium1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Scrolldown_document {

	public static void main(String arg[]) throws InterruptedException {
		System.setProperty("WebDriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(1000);
		js.executeScript("document.querySelector('.tableFixHead').scrollTop=500;");
		Thread.sleep(1000);

		List<WebElement> value = driver.findElements(By.xpath("//*[@id=\"product\"]/tbody/tr/td[4]"));
		int sum = 0;

		for (int i = 0; i < value.size(); i++) {

			sum = sum +Integer.parseInt(value.get(i).getText());
			
		}
		System.out.println(sum);
		String str = driver.findElement(By.xpath("//div[2]/fieldset[2]/div[2]")).getText();
		String total=str.split(":")[1].trim();
		int Total = Integer.parseInt(total);	
		
		if(sum==Total)
			System.out.println("true");
		
		Assert.assertEquals(sum, Total);
		driver.close();
	}
}
